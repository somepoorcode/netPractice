import requests

url = 'https://httpbin.org/'


resp = requests.options(url + 'get')
with open("options.txt", "w", encoding="utf-8") as f:
    f.write("OPTIONS\n\n")
    f.write(f"Код ответа: {resp.status_code}\n")
    f.write(f"Заголовки ответа: {resp.headers}\n")
    f.write(f"Тело ответа:\n{resp.text}\n\n")


resp = requests.get(url + 'get')
with open("get.txt", "w", encoding="utf-8") as f:
    f.write("GET\n\n")
    f.write("Текст запроса:\n")
    f.write(f"{resp.request.method} {resp.request.path_url} HTTP/1.1\n\n")
    f.write(f"{resp.request.headers}\n\n")
    f.write(f"Код ответа: {resp.status_code}\n")
    f.write(f"Заголовки ответа: {resp.headers}\n")
    f.write(f"Тело ответа:\n{resp.text}\n\n")


data = {'key': 'value'}
resp = requests.post(url + 'post', data=data)
with open("post.txt", "w", encoding="utf-8") as f:
    f.write("POST\n\n")
    f.write("Текст запроса:\n")
    f.write(f"{resp.request.method} {resp.request.path_url} HTTP/1.1\n\n")
    f.write(f"{resp.request.headers}\n")
    if resp.request.body:
        body = resp.request.body
        if isinstance(body, bytes):
            body = body.decode('utf-8', errors='replace')
        f.write(f"\n{body}\n\n")
    else:
        f.write("\n")
    f.write(f"Код ответа: {resp.status_code}\n")
    f.write(f"Заголовки ответа: {resp.headers}\n")
    f.write(f"Тело ответа:\n{resp.text}\n")
